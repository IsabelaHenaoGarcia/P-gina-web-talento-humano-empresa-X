# frontend-sgrh

Frontend Next.js + TypeScript para el Sistema de Gestion de Recursos Humanos (SGRH).

## Requisitos

- Node.js 18 o superior
- npm
- Backend activo en `http://localhost:8000`

## Instalacion

Desde `frontend-sgrh/`:

```bash
npm install
```

## Variables de entorno

Crear un archivo `.env.local` con:

```bash
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
```

Si no se define, el frontend usa `http://localhost:8000` por defecto.

## Ejecutar en desarrollo

```bash
npm run dev
```

La aplicacion queda disponible en:

```text
http://localhost:3000
```

## Comandos utiles

```bash
npm run build
npm run lint
npm run typecheck
```

## Orden recomendado para levantar el proyecto completo

1. Iniciar el backend en `backend-sgrh/`.
2. Verificar `http://localhost:8000/docs`.
3. Iniciar el frontend en `frontend-sgrh/`.
4. Abrir `http://localhost:3000`.

## Rutas principales

- `/login`
- `/dashboard`
- `/employees`
- `/recruitment/candidates`
- `/affiliations`
- `/payroll/periods`
- `/offboarding`
- `/training/activities`
- `/evaluations`
- `/certificates`
- `/reports`
- `/audit`
- `/admin/users`
