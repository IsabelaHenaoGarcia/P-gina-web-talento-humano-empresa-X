import { CandidateFormPage } from "@/features/recruitment";

export default function Page() {
  return <CandidateFormPage />;
}
