import { CandidatesListPage } from "@/features/recruitment";

export default function Page() {
  return <CandidatesListPage />;
}
