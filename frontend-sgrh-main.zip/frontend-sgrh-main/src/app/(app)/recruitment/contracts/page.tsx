import { ContractsPage } from "@/features/recruitment";

export default function Page() {
  return <ContractsPage />;
}
