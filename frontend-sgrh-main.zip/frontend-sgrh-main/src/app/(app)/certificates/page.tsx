import { CertificatesPage } from "@/features/operations";

export default function Page() {
  return <CertificatesPage />;
}
