import { OffboardingPage } from "@/features/operations";

export default function Page() {
  return <OffboardingPage />;
}
