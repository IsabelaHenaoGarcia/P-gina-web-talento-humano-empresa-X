import { OffboardingNewPage } from "@/features/operations";

export default function Page() {
  return <OffboardingNewPage />;
}
