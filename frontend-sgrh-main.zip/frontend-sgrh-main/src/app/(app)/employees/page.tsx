import { EmployeesListPage } from "@/features/employees";

export default function Page() {
  return <EmployeesListPage />;
}
