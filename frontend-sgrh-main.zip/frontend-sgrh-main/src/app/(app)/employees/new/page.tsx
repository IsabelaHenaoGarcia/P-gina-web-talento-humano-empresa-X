import { EmployeeFormPage } from "@/features/employees";

export default function Page() {
  return <EmployeeFormPage />;
}
