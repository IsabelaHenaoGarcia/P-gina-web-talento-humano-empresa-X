import { PayrollPeriodDetailPage } from "@/features/operations";

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <PayrollPeriodDetailPage periodId={id} />;
}
