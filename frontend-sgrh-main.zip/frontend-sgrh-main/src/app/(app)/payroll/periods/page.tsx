import { PayrollPeriodsPage } from "@/features/operations";

export default function Page() {
  return <PayrollPeriodsPage />;
}
