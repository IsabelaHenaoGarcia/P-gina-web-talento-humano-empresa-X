import { ReportsPage } from "@/features/operations";

export default function Page() {
  return <ReportsPage />;
}
