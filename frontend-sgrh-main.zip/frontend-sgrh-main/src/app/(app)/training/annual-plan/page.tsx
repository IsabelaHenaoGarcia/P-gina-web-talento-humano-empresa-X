import { TrainingAnnualPlanPage } from "@/features/operations";

export default function Page() {
  return <TrainingAnnualPlanPage />;
}
