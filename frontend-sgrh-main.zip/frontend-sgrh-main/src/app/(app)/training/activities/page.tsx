import { TrainingActivitiesPage } from "@/features/operations";

export default function Page() {
  return <TrainingActivitiesPage />;
}
