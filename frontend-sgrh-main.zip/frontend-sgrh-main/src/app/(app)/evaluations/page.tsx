import { EvaluationsPage } from "@/features/operations";

export default function Page() {
  return <EvaluationsPage />;
}
