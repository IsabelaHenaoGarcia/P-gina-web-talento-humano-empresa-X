import { AffiliationNewPage } from "@/features/operations";

export default function Page() {
  return <AffiliationNewPage />;
}
