import { AffiliationsPage } from "@/features/operations";

export default function Page() {
  return <AffiliationsPage />;
}
