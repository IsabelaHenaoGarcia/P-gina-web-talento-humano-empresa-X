import { AuditPage } from "@/features/operations";

export default function Page() {
  return <AuditPage />;
}
