import { AdminUsersPage } from "@/features/operations";

export default function Page() {
  return <AdminUsersPage />;
}
